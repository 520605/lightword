package cn.itcast.appwordbook;

import android.os.AsyncTask;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

class NetworkUtil {
    private static final String TAG = "NetworkUtil";

    public interface OnWordQueryListener {
        void onQuerySuccess(String explanation);
        void onQueryFailed(String error);
    }

    public static void queryWord(String word, OnWordQueryListener listener) {
        new QueryWordTask(listener).execute(word);
    }
    private static class QueryWordTask extends AsyncTask<String, Void, String> {
        private OnWordQueryListener listener;

        public QueryWordTask(OnWordQueryListener listener) {
            this.listener = listener;
        }

        @Override
        protected String doInBackground(String... params) {
            String word = params[0];
            String urlString = "https://dict.youdao.com/suggest?q=" + word + "&num=1&doctype=json";
            HttpURLConnection connection = null;
            try {
                URL url = new URL(urlString);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setConnectTimeout(5000);
                connection.setReadTimeout(5000);

                int responseCode = connection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()));
                    StringBuilder response = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        response.append(line);
                    }
                    reader.close();

                    JSONObject jsonObject = new JSONObject(response.toString());
                    JSONArray entries = jsonObject.getJSONObject("data").getJSONArray("entries");
                    if (entries.length() > 0) {
                        return entries.getJSONObject(0).getString("explain");
                    }
                } else {
                    Log.e(TAG, "查询单词失败，状态码: " + responseCode);
                    return null;
                }
            } catch (IOException | JSONException e) {
                Log.e(TAG, "查询单词失败", e);
                return null;
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }
            return word;
        }


        @Override
        protected void onPostExecute(String result) {
            if (result!= null) {
                listener.onQuerySuccess(result);
            } else {
                listener.onQueryFailed("查询失败");
            }
        }
    }
}
