package cn.itcast.appwordbook;

import android.content.ContentValues;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private EditText etWord;
    private TextView tvExplanation;
    private DBHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etWord = findViewById(R.id.et_word);
        Button btnSearch = findViewById(R.id.btn_search);
        tvExplanation = findViewById(R.id.tv_explanation);
        Button btnFavorites = findViewById(R.id.btn_favorites);
        dbHelper = new DBHelper(this);

        btnSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final String word = etWord.getText().toString().trim();
                if (!word.isEmpty()) {
                    NetworkUtil.queryWord(word, new NetworkUtil.OnWordQueryListener() {
                        @Override
                        public void onQuerySuccess(String explanation) {
                            tvExplanation.setText("解释: " + explanation);
                            saveToDatabase(word, explanation);
                        }

                        @Override
                        public void onQueryFailed(String error) {
                            Toast.makeText(MainActivity.this, error, Toast.LENGTH_SHORT).show();
                        }
                    });
                } else {
                    Toast.makeText(MainActivity.this, "请输入单词", Toast.LENGTH_SHORT).show();
                }
            }
        });

        btnFavorites.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, FavoritesActivity.class);
                startActivity(intent);
            }
        });
    }

    private void saveToDatabase(String word, String explanation) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DBHelper.COLUMN_WORD, word);
        values.put(DBHelper.COLUMN_EXPLANATION, explanation);
        values.put(DBHelper.COLUMN_FAMILIARITY, "*");

        try {
            // 使用 ContentValues 插入数据，避免 SQL 注入风险
            long newRowId = db.insert(DBHelper.TABLE_NAME, null, values);
            if (newRowId == -1) {
                // 如果返回 -1，则表示插入失败
                Toast.makeText(this, "单词已存在于收藏夹", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "单词已添加到收藏夹", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            Toast.makeText(this, "保存数据失败: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        } finally {
            db.close();
        }
    }
    }
