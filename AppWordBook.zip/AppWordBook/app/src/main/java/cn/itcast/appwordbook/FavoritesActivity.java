package cn.itcast.appwordbook;

import android.app.Activity;
import android.content.ContentValues;
import android.content.DialogInterface;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Spinner;

import java.util.ArrayList;

import static cn.itcast.appwordbook.DBHelper.COLUMN_EXPLANATION;
import static cn.itcast.appwordbook.DBHelper.COLUMN_FAMILIARITY;
import static cn.itcast.appwordbook.DBHelper.COLUMN_WORD;
import static cn.itcast.appwordbook.DBHelper.TABLE_NAME;

public class FavoritesActivity extends Activity {
    private DBHelper dbHelper;
    private ArrayAdapter<String> adapter;
    private ArrayList<String> favoritesList;
    private String selectedWord; // 用于存储当前选中的单词

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_favorite); // 确保这是正确的布局文件

        ListView listView = findViewById(R.id.lv_favorites);
        final Spinner spinner = findViewById(R.id.spinner_familiarity);
        Button btnFilter = findViewById(R.id.btn_filter);

        dbHelper = new DBHelper(this);
        favoritesList = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, favoritesList);
        listView.setAdapter(adapter);

        loadFavorites(null); // 传递null以加载所有收藏夹单词

        // Spinner 相关代码
        ArrayAdapter<CharSequence> spinnerAdapter = ArrayAdapter.createFromResource(this, R.array.familiarity_levels, android.R.layout.simple_spinner_item);
        spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinner.setAdapter(spinnerAdapter);

        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                String selectedFamiliarity = parent.getItemAtPosition(position).toString();
                // 更新熟悉度前确保有一个单词被选中
                if (selectedWord != null) {
                    updateFamiliarity(selectedWord, selectedFamiliarity);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing
            }
        });

        // 设置ListView的点击监听器来弹出对话框选择熟悉度
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                final String item = (String) parent.getItemAtPosition(position);
                final String word = item.split(" - ")[0].trim(); // 提取单词

                // 弹出对话框让用户选择熟悉度
                showFamiliarityDialog(word);
            }
        });

        // 设置筛选按钮的点击事件监听器
        btnFilter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // 获取 Spinner 中当前选中的熟悉度
                String selectedFamiliarity = (String) spinner.getSelectedItem();
                // 根据选中的熟悉度筛选单词
                loadFavorites(selectedFamiliarity);
            }
        });
    }

    private void showFamiliarityDialog(final String word) {
        // 创建一个对话框
        AlertDialog.Builder builder = new AlertDialog.Builder(FavoritesActivity.this);
        builder.setTitle("选择熟悉度等级");

        // 设置下拉列表
        final String[] familiarityLevels = getResources().getStringArray(R.array.familiarity_levels);
        builder.setItems(familiarityLevels, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String selectedFamiliarity = familiarityLevels[which];
                updateFamiliarity(word, selectedFamiliarity);
            }
        });

        // 显示对话框
        AlertDialog dialog = builder.create();
        dialog.show();
    }

    public void addToFavorites(String word, String explanation) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_WORD, word);
        values.put(COLUMN_EXPLANATION, explanation);
        values.put(COLUMN_FAMILIARITY, "完全陌生"); // 设置默认熟悉度等级为 '完全陌生'
        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    private void loadFavorites(String filter) {
        SQLiteDatabase db = dbHelper.getReadableDatabase();
        Cursor cursor;
        String selection = null;
        String[] selectionArgs = null;
        if (filter != null) {
            selection = COLUMN_FAMILIARITY + " = ?";
            selectionArgs = new String[]{filter};
        }
        cursor = db.query(TABLE_NAME, null, selection, selectionArgs, null, null, null);

        favoritesList.clear(); // 清除现有列表以避免重复添加
        while (cursor.moveToNext()) {
            String word = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_WORD));
            String explanation = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_EXPLANATION));
            String familiarity = cursor.getString(cursor.getColumnIndexOrThrow(COLUMN_FAMILIARITY));
            // 显示单词时附带熟悉度分级
            favoritesList.add(word + " - " + explanation + " (" + familiarity + ")");
        }
        cursor.close();
        adapter.notifyDataSetChanged(); // 通知适配器数据已更改
        db.close();
    }

    // 完整的 updateFamiliarity 方法
    private void updateFamiliarity(String word, String newFamiliarity) {
        SQLiteDatabase db = dbHelper.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(COLUMN_FAMILIARITY, newFamiliarity);
        int rowsAffected = db.update(TABLE_NAME, values, COLUMN_WORD + " = ?", new String[]{word});
        if (rowsAffected > 0) {
            // 如果单词的熟悉度已更新，重新加载列表
            loadFavorites(null);
        }
        db.close();
    }
}
