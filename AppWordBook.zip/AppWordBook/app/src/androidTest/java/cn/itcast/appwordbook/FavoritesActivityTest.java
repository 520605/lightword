package cn.itcast.appwordbook;

import static org.junit.Assert.*;

public class FavoritesActivityTest {

}